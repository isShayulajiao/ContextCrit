# 交付验证记录

- 环境：Python 3.12.14 / Linux；工具要求Python 3.10+。
- 命令：`python -m unittest discover -v`
- 结果：58项测试全部通过，耗时约6.8秒。
- 双文件校验：`python consistency_check.py --input example_1.json example_2.json --check-only --output-dir demo_validation`，四条T1–T4合成样本有效，无API请求。
- 统计：手算ordinal α与Fleiss κ、负系数、缺失评级、常数/空集分母退化；另经独立公式实现核对各1000组随机α/κ输入，误差小于1e-12。
- HTTP/CLI：仅localhost模拟服务；验证三个模型独立请求、两文件限条、成功评分复用、失败补评、401停批、类型/格式异常、截断用量保存、脱敏、指纹变化拒绝续跑及分任务输出。
- 报告：合并及各输入文件分别保留T1–T4，CSV/JSON合计12行宽表，每行含五维κ/α；report.md按任务/维度展开合计60行；空输入文件仍保留各任务各维度并注明统计量未定义。
- 未进行真实付费API调用，未使用用户密钥；交付config.json三个api_key均为空。
- Windows专用文件锁分支尚未在Windows执行；真实账号、模型权限、网关兼容性与限流需配置后验证。

## v2 五维κ补充验证

- 五维Fleiss κ将1–5分视为五个名义类别，保留ordinal α；原标签κ另列label_kappa。
- 新增五分类手算、负κ、缺失/常数/严格类型验证，并独立对照1000组随机五分类数据。
- 端到端例中五维κ=5/11、ordinal α=7/8，而标签κ=1，证明报表未混用两种κ。
- 使用旧版代码生成的SQLite checkpoint，在新版运行report-only成功；API请求数保持不变，未重新评分。
