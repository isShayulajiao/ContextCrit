"""便于阅读的结果表；展示换算不改写正式评分或补齐缺失结果。"""
from __future__ import annotations

import csv
import io
import json
from pathlib import Path
from statistics import mean

from .storage import atomic_write


TASKS = ("T1", "T2", "T3", "T4")
TASK_SPECIFIC_METRICS = {
    "relation_quality_score": "T2",
    "memory_state_f1": "T3",
    "memory_turn_mean_f1": "T3",
    "false_overwrite": "T3",
    "expected_exchange_recall": "T4",
    "task_success_rate": "T4",
}
METRIC_LABELS = {
    "composite": "任务综合分（固定权重）",
    "macro_task_score": "四任务综合分等权宏平均",
    "evidence_f1": "证据 F1",
    "evidence_precision": "证据精确率",
    "evidence_recall": "证据召回率",
    "citation_validity_mean": "引用有效率",
    "answer_citations_match_claims_rate": "回答引用与主张一致率",
    "expected_exchange_recall": "预期交换召回率（诊断）",
    "claim_coverage": "主张覆盖率",
    "claim_precision": "主张精确率",
    "claim_f1": "主张 Micro-F1",
    "aspect_micro_f1": "方面 Micro-F1",
    "stance_macro_f1": "立场 Macro-F1",
    "stance_f1_POSITIVE": "正面立场 F1",
    "stance_f1_NEGATIVE": "负面立场 F1",
    "stance_f1_MIXED": "混合立场 F1",
    "stance_f1_NEUTRAL": "中立立场 F1",
    "relation_quality_score": "关系解释质量",
    "memory_state_f1": "最终记忆状态 F1",
    "memory_turn_mean_f1": "全部预期轮次记忆 F1 均值",
    "false_overwrite": "误覆盖率（越低越好；诊断）",
    "task_success_rate": "任务成功率",
}
COLUMNS_ZH = {
    "dataset": "数据集", "scope": "范围", "task": "任务",
    "metric": "指标代码", "metric_label": "指标说明", "row_type": "结果类型",
    "source": "来源", "judge": "裁判", "raw_0_1": "原始分_0至1",
    "display_0_100": "展示分_0至100", "complete": "该项评分完整",
    "diagnostic": "仅作诊断", "valid_judges": "完整裁判数",
    "expected_judges": "预定裁判数", "valid_tasks": "完整任务数",
    "expected_tasks": "预定任务数", "coverage_raw_0_1": "覆盖率_0至1",
    "coverage_basis": "覆盖率口径", "notes": "说明",
}


def metric_applies_to_task(metric, task):
    """展示层略去其他任务专属指标，保留原始报告全部字段。"""
    return metric not in TASK_SPECIFIC_METRICS or TASK_SPECIFIC_METRICS[metric] == task


def _semantic_complete(sample):
    return bool(sample.get("semantic_counts", {}).get("scored")) and not sample.get("needs_alignment", False)


def _failed_empty(sample):
    counts = sample.get("semantic_counts", {})
    return (sample.get("status") in ("FAILED", "PARTIAL")
            and counts.get("predicted") == 0 and counts.get("expected", 0) > 0
            and _semantic_complete(sample))


def _coverage(samples, baseline):
    """完整样本覆盖率独立于质量分；自动零分须有裁判前程序记录佐证。"""
    expected = {s["sample_id"]: s for s in baseline if s.get("status") != "INPUT_INVALID"}
    observed = {s["sample_id"]: s for s in samples if s.get("sample_id") in expected}
    scored = [s for s in observed.values() if _semantic_complete(s)]
    nonempty_expected = sum((s.get("semantic_counts", {}).get("predicted") or 0) > 0 for s in expected.values())
    nonempty_graded = sum((s.get("semantic_counts", {}).get("predicted") or 0) > 0 for s in scored)
    auto_zero = sum(_failed_empty(s) and _failed_empty(expected[s["sample_id"]]) for s in scored)
    turns = [turn for sample in observed.values() for turn in sample.get("turns", [])]
    return {
        "expected_samples": len(expected), "observed_samples": len(observed),
        "semantic_scored_samples": len(scored),
        "semantic_unscored_samples": len(expected) - len(scored),
        "semantic_coverage_raw_0_1": len(scored) / len(expected) if expected else None,
        "nonempty_prediction_samples": nonempty_expected,
        "nonempty_graded_samples": nonempty_graded,
        "nonempty_judging_coverage_raw_0_1": nonempty_graded / nonempty_expected if nonempty_expected else None,
        "failed_empty_auto_zero_samples": auto_zero,
        "other_empty_scored_samples": len(scored) - nonempty_graded - auto_zero,
        "observed_expected_turns": len(turns),
        "scored_turns": sum(bool(t.get("scored")) for t in turns),
    }


def report_coverage(report):
    """从已有报告恢复执行状态与评分覆盖，未知的流程完成状态保留 null。"""
    baseline = [s.get("program", s) for s in report.get("per_sample", [])]
    summary = report.get("overall", {}).get("program_summary", {})
    statuses = dict(summary.get("status_counts", {}))
    if not statuses:
        for sample in baseline:
            status = sample.get("status", "UNKNOWN")
            statuses[status] = statuses.get(status, 0) + 1
    judges = {}
    for name in report.get("expected_judges", []):
        result = report.get("per_judge", {}).get(name) or {}
        samples = (result.get("metrics") or {}).get("per_sample", [])
        judges[name] = {
            "status": result.get("status", "missing"),
            "overall": _coverage(samples, baseline),
            "per_task": {task: _coverage([s for s in samples if s.get("task") == task],
                                         [s for s in baseline if s.get("task") == task]) for task in TASKS},
        }
    return {
        "sample_count": summary.get("count", len(baseline)),
        "sample_status_counts": statuses,
        "judging_complete": report.get("judging_complete"),
        "formal_scores_complete": all(_complete(report["per_task"][task]["composite"], report["expected_judges"])
                                      for task in TASKS),
        "per_judge": judges,
        "notes": [
            "COMPLETED/PARTIAL 是被测样本执行状态；judging_complete 是裁判流程状态，两者独立。",
            "语义已评分数包含失败空预测的程序自动零分，不能当作非空输出已完成裁判评分数。",
            "非空主张按现有 semantic_counts.predicted > 0 计数；T3 另列已有预期轮次及已评分轮次。",
            "自动零分数仅统计裁判前程序记录已确认的失败空预测，其他空输出不推定为自动零分。",
        ],
    }


def _complete(stats, judges):
    if not stats.get("complete") or stats.get("mean") is None:
        return False
    if stats.get("source") == "program":
        return True
    return bool(judges) and all(
        stats.get("per_judge", {}).get(name, {}).get("complete")
        and stats.get("per_judge", {}).get(name, {}).get("value") is not None
        for name in judges)


def _row(report, scope, task, metric, row_type, source, value, complete, diagnostic, **extras):
    return {
        "dataset": report["dataset_name"], "scope": scope, "task": task,
        "metric": metric, "metric_label": METRIC_LABELS.get(metric, metric),
        "row_type": row_type, "source": source, "judge": "",
        "raw_0_1": value, "display_0_100": round(value * 100, 4) if value is not None else None,
        "complete": bool(complete), "diagnostic": bool(diagnostic),
        "valid_judges": None, "expected_judges": None,
        "valid_tasks": None, "expected_tasks": None,
        "coverage_raw_0_1": None, "coverage_basis": "", "notes": "", **extras,
    }


def _metric_rows(report, section, scope, task, coverage):
    judges = report["expected_judges"]
    values = dict(section.get("metrics", {}))
    if section.get("composite"):
        values["composite"] = section["composite"]
    for metric, stats in values.items():
        if scope == "task" and not metric_applies_to_task(metric, task):
            continue
        complete = _complete(stats, judges)
        program = stats.get("source") == "program"
        valid = stats.get("valid_judges", 0)
        expected = len(judges) if not program else 0
        counts = {"valid_judges": valid, "expected_judges": expected,
                  "coverage_raw_0_1": valid / expected if expected else None,
                  "coverage_basis": "完整裁判/预定裁判" if expected else "程序计算；不适用裁判覆盖率"}
        yield _row(report, scope, task, metric, "正式值", "程序" if program else "全部预定裁判均值",
                   stats.get("mean") if complete else None, complete, False, **counts,
                   notes="null 表示未完整评分、无有效分母或不适用，不等于零分。")
        if not complete and stats.get("available_mean") is not None:
            yield _row(report, scope, task, metric, "可用值（诊断）", "程序" if program else "完整裁判子集均值",
                       stats["available_mean"], False, True, **counts,
                       notes="仅保留原报告可用值；覆盖不足，不能作为正式结果。")
        if program:
            continue
        for name in judges:
            entry = stats.get("per_judge", {}).get(name, {})
            judge_complete = bool(entry.get("complete") and entry.get("value") is not None)
            judge_coverage = coverage["per_judge"][name]["overall" if scope == "overall" else "per_task"]
            if scope != "overall":
                judge_coverage = judge_coverage[task]
            yield _row(report, scope, task, metric, "单裁判值（诊断）", "独立裁判", entry.get("value"),
                       judge_complete, True, judge=name,
                       coverage_raw_0_1=judge_coverage["semantic_coverage_raw_0_1"],
                       coverage_basis="语义完整样本/有效样本；不是质量分或该指标有效分母覆盖率",
                       notes=("该裁判本指标完整；单裁判值独立列出。" if judge_complete else
                              "该裁判本指标未完整评分或无有效分母；现有原始值仅作诊断，不能进入正式均值。"))


def build_results_overview(report):
    """保留原始分和 null；只将已有分数乘 100 用于展示。"""
    coverage = report_coverage(report)
    rows = []
    overall_complete = coverage["formal_scores_complete"] and report["overall"].get("macro_task_score") is not None
    overall_value = report["overall"].get("macro_task_score") if overall_complete else None
    valid_tasks = sum(_complete(report["per_task"][task]["composite"], report["expected_judges"]) for task in TASKS)
    rows.append(_row(report, "overall", "", "macro_task_score", "正式值", "四任务等权宏平均",
                     overall_value, overall_complete, False, valid_tasks=valid_tasks, expected_tasks=len(TASKS),
                     coverage_raw_0_1=valid_tasks / len(TASKS), coverage_basis="完整任务/四任务",
                     notes="全部预定裁判完整且 T1–T4 都有正式综合分时才给出正式整体分。"))
    for task in TASKS:
        rows.extend(_metric_rows(report, {"composite": report["per_task"][task]["composite"]}, "task", task, coverage))
    for name in report["expected_judges"]:
        entries = [report["per_task"][task]["composite"].get("per_judge", {}).get(name, {}) for task in TASKS]
        valid = sum(bool(e.get("complete") and e.get("value") is not None) for e in entries)
        value = mean(e["value"] for e in entries) if valid == len(TASKS) else None
        rows.append(_row(report, "overall", "", "macro_task_score", "单裁判值（诊断）", "四任务等权宏平均",
                         value, valid == len(TASKS), True, judge=name, valid_tasks=valid, expected_tasks=len(TASKS),
                         coverage_raw_0_1=valid / len(TASKS), coverage_basis="该裁判完整任务/四任务",
                         notes="只在该裁判四个原始任务综合分均完整时求均值；缺项保持 null。"))
    for task in TASKS:
        rows.extend(_metric_rows(report, {"metrics": report["per_task"][task].get("metrics", {})}, "task", task, coverage))
    rows.extend(_metric_rows(report, report["overall"], "overall", "", coverage))
    return {
        "schema_version": "1.0", "dataset_name": report["dataset_name"],
        "raw_score_range": [0, 1], "display_score_range": [0, 100],
        "display_rule": "display_0_100 = raw_0_1 × 100，保留四位小数；不做 min-max 归一化。",
        "missing_rule": "JSON null / CSV 空单元格表示未知、未完整评分或无有效分母；不等于 0。",
        "formal_rule": "正式语义均值须全部预定裁判完整；整体均分须四任务正式综合分全部可用。",
        "composite_weights": report.get("methodology", {}).get("composite_weights", {}),
        "coverage": coverage, "columns_zh": COLUMNS_ZH, "rows": rows,
    }


def write_results_overview(report, run_dir):
    """生成中文可读的总分、任务综合分、所有指标与逐裁判诊断表。"""
    overview = build_results_overview(report)
    directory = Path(run_dir)
    atomic_write(directory / "scores_overview.json", json.dumps(overview, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=list(COLUMNS_ZH.values()))
    writer.writeheader()
    writer.writerows({label: row[key] for key, label in COLUMNS_ZH.items()} for row in overview["rows"])
    atomic_write(directory / "scores_overview.csv", stream.getvalue())
    return overview
