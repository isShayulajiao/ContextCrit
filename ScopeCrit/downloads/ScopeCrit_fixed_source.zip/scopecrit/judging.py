"""独立模型裁判：先做一对一语义对齐，再复用确定性的指标计算。

评分数据只在答题结束后进入此模块，不会回传给 Agent。每个裁判使用独立
请求和独立客户端。调用日志与缓存另存 judges/state.sqlite3，不改变答题状态。
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sqlite3
import time
from concurrent.futures import ThreadPoolExecutor
from threading import RLock
from typing import Literal
from uuid import uuid4

from pydantic import Field

from .data import fingerprint
from .evaluation import evaluate_predictions
from .judge_config import resolved_base_url
from .judge_providers import make_judge_provider
from .json_protocol import parse_model_json, validation_feedback
from .schemas import Claim, StrictModel
from .storage import atomic_write, synchronized


class Match(StrictModel):
    predicted_claim_id: str
    gold_claim_id: str
    relation: Literal["equivalent"]
    note: str = Field(default="", max_length=500)


class Alignment(StrictModel):
    sample_id: str
    turn: int | None
    alignment_complete: bool
    matches: list[Match]
    relation_quality: Literal["correct", "partial", "incorrect", "unscored"] | None = None
    dual_dependency: bool | None = None


class JudgeAnswer(StrictModel):
    alignments: list[Alignment]


class JudgeValidationError(ValueError):
    """只携带可公开的字段位置和符号错误；不回显模型输出。"""
    def __init__(self, code, issues):
        self.protocol_code = code
        self.protocol_issues = issues
        super().__init__(code)


def _issue(path, kind):
    return {"path": path, "type": kind}


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False)


def _write(path, value):
    atomic_write(path, json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _project_claim(claim, predicted):
    """含义配对不看 aspect/stance/证据标签，避免循环定义标签正确性。"""
    key = "predicted_claim_id" if predicted else "claim_id"
    return {key: claim[key], "text": claim["text"], "target_scope": claim.get("target_scope", "")}


def _relation(relation):
    return {k: deepcopy(relation[k]) for k in
            ("relation_id", "claim_ids", "evidence_ids", "relation_type", "explanation") if k in relation}


def _evidence(evidence):
    return {key: evidence[key] for key in ("evidence_id", "text", "start", "end")}


def _preflight_prediction(sample, prediction):
    """本地坏输入不属于裁判格式错误，必须在任何付费调用之前明确拒绝。"""
    sid = sample["sample_id"]
    final, turns = prediction.get("prediction", {}), prediction.get("turns", [])
    if not isinstance(final, dict) or not isinstance(turns, list):
        raise ValueError(f"JUDGE_SCORING_INPUT_INVALID: {sid}: prediction_or_turns_structure")
    groups = [(["prediction", "claims"], final.get("claims", []))]
    for index, turn in enumerate(turns):
        if not isinstance(turn, dict):
            raise ValueError(f"JUDGE_SCORING_INPUT_INVALID: {sid}: turns[{index}]: object_type")
        groups.append((["turns", index, "claims"], turn.get("claims", [])))
    for path, claims in groups:
        if not isinstance(claims, list):
            raise ValueError(f"JUDGE_SCORING_INPUT_INVALID: {sid}: {_json(_issue(path, 'list_type'))}")
        seen = set()
        for index, claim in enumerate(claims):
            location = path + [index]
            try:
                if not isinstance(claim, dict):
                    raise JudgeValidationError("JUDGE_SCORING_INPUT_INVALID", [_issue([], "object_type")])
                # 引擎保存的状态元数据不是 Claim 字段；评分所需字段仍使用同一严格 schema。
                Claim.model_validate({key: claim[key] for key in Claim.model_fields if key in claim})
                pid = claim.get("predicted_claim_id")
                if not isinstance(pid, str) or not pid:
                    raise JudgeValidationError("JUDGE_SCORING_INPUT_INVALID", [_issue(["predicted_claim_id"], "required_string_id")])
                if pid in seen:
                    raise JudgeValidationError("JUDGE_SCORING_INPUT_INVALID", [_issue(["predicted_claim_id"], "duplicate_predicted_claim_id")])
                seen.add(pid)
            except ValueError as exc:
                feedback = validation_feedback(exc)
                for issue in feedback["issues"]:
                    issue["path"] = location + issue["path"]
                raise ValueError(f"JUDGE_SCORING_INPUT_INVALID: {sid}: {_json(feedback)}") from None
    try:
        evaluate_predictions([prediction], [sample], None)
    except (ValueError, TypeError, KeyError, AttributeError):
        raise ValueError(f"JUDGE_SCORING_INPUT_INVALID: {sid}: prediction_structure") from None


def build_judge_request(sample, prediction):
    """白名单构造评分请求，不携带答题模型名称、其他裁判意见或隐藏推理。"""
    gold_claims = sample["gold"]["claims"]
    final = prediction.get("prediction", {})
    targets = [{"sample_id": sample["sample_id"], "turn": None,
                "question": sample.get("question", ""),
                "predicted_claims": [_project_claim(c, True) for c in final.get("claims", [])],
                "gold_claims": [_project_claim(c, False) for c in gold_claims],
                "answer": final.get("answer", ""),
                "relations": [_relation(r) for r in final.get("relations", [])]}]
    if sample["task"] == "T3":
        for event in sample["events"]:
            snapshot = next((t for t in prediction.get("turns", []) if t["turn"] == event["turn"]), {})
            ids = set(event["gold_memory_state"])
            targets.append({"sample_id": sample["sample_id"], "turn": event["turn"],
                            "question": event.get("question", ""),
                            "predicted_claims": [_project_claim(c, True) for c in snapshot.get("claims", [])],
                            "gold_claims": [_project_claim(c, False) for c in gold_claims if c["claim_id"] in ids],
                            "answer": snapshot.get("answer", ""), "relations": []})
    for target in targets:
        # 明确区分两个 ID 命名空间；T3 只允许当前轮的 ID，T4 保留角色前缀。
        target["allowed_predicted_claim_ids"] = [c["predicted_claim_id"] for c in target["predicted_claims"]]
        target["allowed_gold_claim_ids"] = [c["claim_id"] for c in target["gold_claims"]]
    document = sample["document"]
    request = {"task": sample["task"], "work_title": document.get("work_title", ""),
               "source": {"text": document["text"], "evidence": [_evidence(e) for e in document["evidence"]]},
               "targets": targets}
    if sample["task"] == "T4":
        request["collaboration"] = {
            "initial_evidence": {role: list(ids) for role, ids in sample["roles"].items()},
            "delivered_messages": [{"from_agent": m["from_agent"], "to_agent": m["to_agent"],
                                     "evidence": [_evidence(e) for e in m.get("evidence", [])]}
                                    for m in prediction.get("messages", [])
                                    if m.get("kind") == "EVIDENCE" and m.get("delivered_event_seq") is not None]}
    return request


def parse_judge_answer(text, sample, prediction, request):
    """严格结构和引用检查；只有合法的一对一配对才能进入指标计算。"""
    parsed = JudgeAnswer.model_validate(parse_model_json(text)).model_dump(exclude_unset=True)
    records = []
    targets = {(t["sample_id"], t["turn"]): t for t in request["targets"]}
    expected = set(targets)
    actual = [(r["sample_id"], r["turn"]) for r in parsed["alignments"]]
    if len(actual) != len(set(actual)) or set(actual) != expected:
        issues = []
        seen = set()
        for index, key in enumerate(actual):
            if key not in expected:
                issues.append(_issue(["alignments", index], "unexpected_target"))
            if key in seen:
                issues.append(_issue(["alignments", index], "duplicate_target"))
            seen.add(key)
        if expected - set(actual):
            issues.append(_issue(["alignments"], "missing_target"))
        raise JudgeValidationError("JUDGE_TARGET_MISMATCH", issues)
    for index, record in enumerate(parsed["alignments"]):
        path = ["alignments", index]
        if sample["task"] == "T2" and record.get("relation_quality") is None:
            raise JudgeValidationError("JUDGE_RELATION_QUALITY_MISSING", [_issue(path + ["relation_quality"], "required_task_field")])
        if sample["task"] == "T4" and "dual_dependency" not in record:
            raise JudgeValidationError("JUDGE_DUAL_DEPENDENCY_MISSING", [_issue(path + ["dual_dependency"], "required_task_field")])
        if sample["task"] != "T2" and "relation_quality" in record:
            raise JudgeValidationError("JUDGE_UNEXPECTED_RELATION_QUALITY", [_issue(path + ["relation_quality"], "unexpected_task_field")])
        if sample["task"] != "T4" and "dual_dependency" in record:
            raise JudgeValidationError("JUDGE_UNEXPECTED_DUAL_DEPENDENCY", [_issue(path + ["dual_dependency"], "unexpected_task_field")])
        # 现有离线评分器对缺失标注保留 null；不能把 null 强行转成 false。
        if record.get("dual_dependency") is None:
            record.pop("dual_dependency", None)
        target = targets[record["sample_id"], record["turn"]]
        pids = {c["predicted_claim_id"] for c in target["predicted_claims"]}
        gids = {c["claim_id"] for c in target["gold_claims"]}
        seen_p, seen_g, issues = set(), set(), []
        for match_index, match in enumerate(record["matches"]):
            match_path = path + ["matches", match_index]
            pid, gid = match["predicted_claim_id"], match["gold_claim_id"]
            if pid not in pids:
                issues.append(_issue(match_path + ["predicted_claim_id"], "unknown_predicted_claim_id"))
            if gid not in gids:
                issues.append(_issue(match_path + ["gold_claim_id"], "unknown_gold_claim_id"))
            if pid in seen_p:
                issues.append(_issue(match_path + ["predicted_claim_id"], "duplicate_predicted_claim_id"))
            if gid in seen_g:
                issues.append(_issue(match_path + ["gold_claim_id"], "duplicate_gold_claim_id"))
            seen_p.add(pid)
            seen_g.add(gid)
        if issues:
            raise JudgeValidationError("JUDGE_INVALID_MATCHES", issues)
        records.append(record)
    # 标签、ID 合法性、重复配对均由同一个确定性评分器检查。
    evaluate_predictions([prediction], [sample], records)
    return records


def _records_complete(records, task):
    return all(r["alignment_complete"]
               and (task != "T2" or r.get("relation_quality") != "unscored")
               and (task != "T4" or type(r.get("dual_dependency")) is bool)
               for r in records)


def _unscored_feedback(records, task):
    issues = []
    for index, record in enumerate(records):
        path = ["alignments", index]
        if not record["alignment_complete"]:
            issues.append(_issue(path + ["alignment_complete"], "alignment_incomplete"))
        if task == "T2" and record.get("relation_quality") == "unscored":
            issues.append(_issue(path + ["relation_quality"], "relation_unscored"))
        if task == "T4" and type(record.get("dual_dependency")) is not bool:
            issues.append(_issue(path + ["dual_dependency"], "dependency_unscored"))
    return {"code": "JUDGE_UNSCORED", "issues": issues}


def _empty_failure_alignment(sample, request):
    """真正失败且没有主张的答卷直接记零，不额外花钱请模型确认空答卷。"""
    records = []
    for target in request["targets"]:
        record = {"sample_id": sample["sample_id"], "turn": target["turn"],
                  "alignment_complete": True, "matches": []}
        if sample["task"] == "T2":
            record["relation_quality"] = "incorrect"
        if sample["task"] == "T4":
            record["dual_dependency"] = False
        records.append(record)
    return records


class JudgeJournal:
    """每次真实尝试独立记录；已知失败可重试，未决调用默认不重复收费。"""
    def __init__(self, path, manifest):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = RLock()
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.invocation = uuid4().hex
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS calls (
                call_id TEXT PRIMARY KEY, logical_id TEXT NOT NULL, generation INTEGER NOT NULL,
                judge TEXT NOT NULL, sample_id TEXT NOT NULL, status TEXT NOT NULL,
                invocation TEXT NOT NULL, request_json TEXT NOT NULL, response_json TEXT,
                error_json TEXT, UNIQUE(logical_id,generation));
        """)
        content = _json(manifest)
        old = self.db.execute("SELECT value FROM metadata WHERE key='manifest'").fetchone()
        if old and old[0] != content:
            self.db.close()
            raise ValueError("JUDGE_FINGERPRINT_MISMATCH: 裁判配置、输入、预测或提示词已改变，请使用新的运行目录")
        with self.db:
            self.db.execute("INSERT OR IGNORE INTO metadata VALUES('manifest',?)", (content,))

    @synchronized
    def bind_endpoint(self, name, endpoint):
        key, value = "endpoint:" + name, fingerprint(endpoint)
        old = self.db.execute("SELECT value FROM metadata WHERE key=?", (key,)).fetchone()
        if old and old[0] != value:
            raise ValueError("JUDGE_ENDPOINT_CHANGED: 裁判接口地址已改变，请使用新的评分目录")
        with self.db:
            self.db.execute("INSERT OR IGNORE INTO metadata VALUES(?,?)", (key, value))

    @synchronized
    def bind_prediction(self, sample_id, request, prediction):
        """已评分答卷冻结；此前未就绪的样本可以在后续恢复时加入。"""
        key = "prediction:" + sample_id
        value = fingerprint([request, prediction])
        old = self.db.execute("SELECT value FROM metadata WHERE key=?", (key,)).fetchone()
        if old and old[0] != value:
            raise ValueError("JUDGE_PREDICTION_CHANGED: 已评分样本的预测已改变，请使用新的评分目录")
        with self.db:
            self.db.execute("INSERT OR IGNORE INTO metadata VALUES(?,?)", (key, value))

    @synchronized
    def latest(self, logical_id):
        row = self.db.execute("SELECT * FROM calls WHERE logical_id=? ORDER BY generation DESC LIMIT 1", (logical_id,)).fetchone()
        return dict(row) if row else None

    @synchronized
    def start(self, logical, judge, sample_id, request, retry_uncertain):
        old = self.latest(logical)
        if old and old["status"] == "COMPLETED":
            return old, False
        if old and old["status"] == "STARTED":
            if not retry_uncertain:
                return old, False
            with self.db:
                self.db.execute("UPDATE calls SET status='UNCERTAIN' WHERE call_id=?", (old["call_id"],))
        elif old and old["status"] == "FAILED" and old["invocation"] == self.invocation:
            return old, False
        generation = old["generation"] + 1 if old else 0
        call_id = f"{logical}:{generation}"
        with self.db:
            self.db.execute("INSERT INTO calls VALUES(?,?,?,?,?,?,?,?,NULL,NULL)",
                            (call_id, logical, generation, judge, sample_id, "STARTED", self.invocation, _json(request)))
        return self.latest(logical), True

    @synchronized
    def finish(self, call_id, response=None, error=None):
        with self.db:
            self.db.execute("UPDATE calls SET status=?,response_json=?,error_json=? WHERE call_id=?",
                            ("COMPLETED" if response is not None else "FAILED",
                             _json(response) if response is not None else None,
                             _json(error) if error is not None else None, call_id))

    @synchronized
    def record_validation(self, call_id, error):
        """传输成功与裁判内容有效性分别记录，保留真实调用及 token 统计。"""
        with self.db:
            self.db.execute("UPDATE calls SET error_json=? WHERE call_id=? AND status='COMPLETED'",
                            (_json(error), call_id))

    @synchronized
    def calls(self, name=None):
        if name is None:
            rows = self.db.execute("SELECT * FROM calls ORDER BY rowid").fetchall()
        else:
            rows = self.db.execute("SELECT * FROM calls WHERE judge=? ORDER BY rowid", (name,)).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            for key in ("request", "response", "error"):
                content = item.pop(key + "_json")
                item[key] = json.loads(content) if content is not None else None
            result.append(item)
        return result

    @synchronized
    def close(self):
        self.db.close()


class JudgeFailure(Exception):
    def __init__(self, code, fatal=False, uncertain=False):
        self.code, self.fatal, self.uncertain = code, fatal, uncertain


class _LazyProvider:
    """仅在真正需要新请求时检查认证；读取已保存响应不需要重新配置密钥。"""
    def __init__(self, judge, journal):
        self.judge, self.journal, self.client = judge, journal, None

    def prepare(self):
        if self.client is None:
            try:
                client = make_judge_provider(self.judge)
                endpoint = resolved_base_url(self.judge) if self.judge.get("provider") else self.judge.get("base_url")
                self.journal.bind_endpoint(self.judge["name"], endpoint or "provider-default")
            except ValueError:
                raise JudgeFailure("JUDGE_CONFIGURATION_MISSING_OR_INVALID", fatal=True) from None
            self.client = client

    def complete(self, prompt, request, call_id):
        return self.client.complete(prompt, request, call_id)


def _safe_response(response):
    """只保留共同响应协议，不允许 SDK headers/密钥/隐藏推理字段进入日志。"""
    keys = ("content", "request_id", "usage", "latency_ms", "provider_name", "model_name", "finish_reason")
    result = {key: response.get(key) for key in keys}
    usage = result.get("usage")
    result["usage"] = ({key: usage.get(key) if type(usage.get(key)) is int else None
                        for key in ("prompt_tokens", "completion_tokens", "total_tokens")}
                       if isinstance(usage, dict) else None)
    reason = result["finish_reason"]
    # 只保存供应商已知的停止码，不把任意错误文本当成诊断字段。
    allowed_reasons = {"stop", "length", "max_tokens", "content_filter", "tool_calls", "function_call",
                       "STOP", "MAX_TOKENS", "SAFETY", "RECITATION", "OTHER"}
    result["finish_reason"] = reason if isinstance(reason, str) and reason in allowed_reasons else None
    return result


def _call(journal, provider, judge, sample_id, request, prompt, config, repair, log, retry_uncertain):
    for attempt in range(config.get("max_api_retries", 2) + 1):
        logical = fingerprint([judge["name"], sample_id, repair, attempt])
        latest = journal.latest(logical)
        cached = latest and (latest["status"] == "COMPLETED" or
                             (latest["status"] == "STARTED" and not retry_uncertain))
        if not cached:
            provider.prepare()
        row, execute = journal.start(logical, judge["name"], sample_id, request, retry_uncertain)
        if not execute:
            if row["status"] == "COMPLETED":
                return json.loads(row["response_json"]), row["call_id"]
            if row["status"] == "STARTED":
                raise JudgeFailure("CALL_UNCERTAIN", uncertain=True)
            error = json.loads(row["error_json"] or "{}")
            if error.get("retryable") and attempt < config.get("max_api_retries", 2):
                continue
            raise JudgeFailure(error.get("code", "JUDGE_API_ERROR"), fatal=error.get("fatal", False))
        log(f'[裁判] {judge["name"]} / {sample_id} / 尝试 {attempt + 1} / 格式修复 {repair}')
        try:
            response = provider.complete(prompt, request, row["call_id"])
        except Exception as exc:
            status = getattr(exc, "status_code", None)
            retryable = status == 429 or (type(status) is int and 500 <= status < 600)
            retryable |= type(exc).__name__ in ("APIConnectionError", "APITimeoutError", "TimeoutError", "ConnectionError")
            code = f"API_{status or type(exc).__name__}"
            fatal = status in (400, 401, 403, 404, 422)
            journal.finish(row["call_id"], error={"code": code, "retryable": retryable, "fatal": fatal})
            if retryable and attempt < config.get("max_api_retries", 2):
                time.sleep(min(2 ** attempt, 8))
                continue
            raise JudgeFailure(code, fatal=fatal) from None
        response = _safe_response(response)
        journal.finish(row["call_id"], response=response)
        return response, row["call_id"]
    raise JudgeFailure("JUDGE_RETRIES_EXHAUSTED")


def _response_diagnostic(response, feedback, code):
    reason = response.get("finish_reason")
    return {"code": code, "validation": feedback, "finish_reason": reason,
            "truncated": reason in ("length", "max_tokens", "MAX_TOKENS")}


def _repair_request(request, feedback, incomplete=False):
    return {**request, "format_repair": {
        "validation": feedback,
        "instruction": (
            "上一响应存在未评分项目，请依据原始材料重新检查所列字段并重新输出全部 targets。"
            "只有已可靠检查全部主张才可设 alignment_complete=true；确实无法判断时仍可返回 false、unscored 或 null。"
            if incomplete else
            "上一响应未通过所列字段检查。请使用本请求各 target 的精确 ID 与 schema 重新输出全部 targets。"
            "不得截断主张、改写 ID、增加标准主张或把非等价配对改标为 equivalent；不等价的主张保持未匹配。"
        )}}


def _stats(calls):
    complete = all(c["status"] == "COMPLETED" and isinstance(c.get("response", {}).get("usage"), dict)
                   and all(type(c["response"]["usage"].get(k)) is int for k in ("prompt_tokens", "completion_tokens", "total_tokens"))
                   for c in calls)
    result = {"model_calls": len(calls), "completed_calls": sum(c["status"] == "COMPLETED" for c in calls),
              "failed_calls": sum(c["status"] == "FAILED" for c in calls),
              "uncertain_calls": sum(c["status"] in ("STARTED", "UNCERTAIN") for c in calls), "usage_complete": complete}
    for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
        values = [c["response"]["usage"][key] for c in calls if c.get("response") and c["response"].get("usage")
                  and type(c["response"]["usage"].get(key)) is int]
        result[key] = sum(values) if complete else None
        result["known_" + key] = sum(values) if values else (0 if not calls else None)
    return result


def _export_judge(folder, name, alignments, metrics, failures, journal):
    folder.mkdir(parents=True, exist_ok=True)
    _write(folder / "alignment.json", alignments)
    _write(folder / "metrics.json", metrics)
    atomic_write(folder / "failures.jsonl", "".join(_json(item) + "\n" for item in failures))
    calls = journal.calls(name)
    atomic_write(folder / "calls.jsonl", "".join(_json(item) + "\n" for item in calls))
    return _stats(calls)


def run_judges(predictions, gold_rows, run_dir, config, log=print, retry_uncertain=False):
    """分别独立对齐，返回各裁判完整指标；均值由 reporting 层另行计算。"""
    if not config.get("enabled", True):
        raise ValueError("裁判配置 enabled=false，不能执行付费自动评分")
    judges = config.get("judges", [])
    if not judges or len({j["name"] for j in judges}) != len(judges):
        raise ValueError("裁判列表不能为空，名称必须唯一")
    indexed = {p["sample_id"]: p for p in predictions}
    gold = {s["sample_id"]: s for s in gold_rows}
    if len(indexed) != len(predictions) or len(gold) != len(gold_rows) or set(indexed) - set(gold):
        raise ValueError("裁判输入 sample_id 重复或不属于数据集")
    for sid, prediction in indexed.items():
        if prediction.get("status") not in ("INPUT_INVALID", "PENDING", "RUNNING", "PAUSED_UNCERTAIN"):
            _preflight_prediction(gold[sid], prediction)
    requests = {sid: build_judge_request(sample, indexed[sid]) for sid, sample in gold.items()
                if sid in indexed and indexed[sid].get("status") != "INPUT_INVALID"}
    base_prompt = (Path(__file__).parent / "prompts" / "judge.txt").read_text(encoding="utf-8")
    prompt = base_prompt + "\n输出结构（严格遵守，不能增加字段）：\n" + _json(JudgeAnswer.model_json_schema())
    directory = Path(run_dir) / "judges"
    directory.mkdir(parents=True, exist_ok=True)
    manifest = {"schema_version": "1.0", "config_fingerprint": fingerprint(config),
                "gold_fingerprint": fingerprint(gold_rows), "prompt_fingerprint": fingerprint(prompt)}
    journal = JudgeJournal(directory / "state.sqlite3", manifest)
    result = {"per_judge": {}, "complete": True, "scoring_source": "llm_judged", "judge_count": len(judges)}
    try:
        for sid, prediction in indexed.items():
            if prediction.get("status") not in ("INPUT_INVALID", "PENDING", "RUNNING", "PAUSED_UNCERTAIN"):
                journal.bind_prediction(sid, requests[sid], prediction)
        def evaluate_judge(judge):
            name = judge["name"]
            folder = directory / hashlib.sha256(name.encode()).hexdigest()[:20]
            records, failures = [], []
            provider = _LazyProvider(judge, journal)
            blocked = False
            eligible, completed = 0, 0
            for sid, sample in gold.items():
                prediction = indexed.get(sid)
                if prediction is None or prediction.get("status") in ("PENDING", "RUNNING", "PAUSED_UNCERTAIN"):
                    failures.append({"sample_id": sid, "code": "PREDICTION_NOT_READY"})
                    continue
                if prediction.get("status") == "INPUT_INVALID":
                    continue
                request = requests[sid]
                eligible += 1
                if prediction.get("status") in ("FAILED", "PARTIAL") and not any(t["predicted_claims"] for t in request["targets"]):
                    records.extend(_empty_failure_alignment(sample, request))
                    completed += 1
                    continue
                if blocked:
                    failures.append({"sample_id": sid, "code": "JUDGE_BLOCKED_BY_PRIOR_ERROR"})
                    continue
                if len(prompt) + len(_json(request)) > config.get("max_input_chars", 120000):
                    failures.append({"sample_id": sid, "code": "JUDGE_CONTEXT_LIMIT"})
                    continue
                current_request = request
                accepted = None
                for repair in range(config.get("max_format_repairs", 1) + 1):
                    try:
                        response, call_id = _call(journal, provider, judge, sid, current_request, prompt, config, repair, log, retry_uncertain)
                        candidate = parse_judge_answer(response["content"], sample, prediction, request)
                    except JudgeFailure as exc:
                        failures.append({"sample_id": sid, "code": exc.code})
                        blocked |= exc.fatal
                        break
                    except (ValueError, TypeError) as exc:
                        feedback = validation_feedback(exc)
                        diagnostic = _response_diagnostic(response, feedback, "INVALID_JUDGE_RESPONSE")
                        journal.record_validation(call_id, diagnostic)
                        if repair < config.get("max_format_repairs", 1):
                            current_request = _repair_request(request, feedback)
                            if len(prompt) + len(_json(current_request)) > config.get("max_input_chars", 120000):
                                failures.append({"sample_id": sid, **diagnostic, "code": "JUDGE_CONTEXT_LIMIT"})
                                break
                            continue
                        failures.append({"sample_id": sid, **diagnostic})
                        break
                    accepted = candidate
                    if _records_complete(candidate, sample["task"]):
                        completed += 1
                        break
                    feedback = _unscored_feedback(candidate, sample["task"])
                    diagnostic = _response_diagnostic(response, feedback, "JUDGE_UNSCORED")
                    journal.record_validation(call_id, diagnostic)
                    if repair < config.get("max_format_repairs", 1):
                        current_request = _repair_request(request, feedback, incomplete=True)
                        if len(prompt) + len(_json(current_request)) <= config.get("max_input_chars", 120000):
                            continue
                        failures.append({"sample_id": sid, **diagnostic, "code": "JUDGE_CONTEXT_LIMIT"})
                    else:
                        failures.append({"sample_id": sid, **diagnostic})
                    break
                if accepted is not None:
                    # 修复失败不覆盖上一份合法但未评分的结果，更不能把未知变成零分。
                    records.extend(accepted)
            metrics = evaluate_predictions(predictions, gold_rows, records)
            stats = _export_judge(folder, name, records, metrics, failures, journal)
            if any(f["code"] == "CALL_UNCERTAIN" for f in failures):
                status = "PAUSED_UNCERTAIN"
            elif not failures and eligible > 0 and completed == eligible:
                status = "COMPLETED"
            else:
                status = "PARTIAL" if completed else "FAILED"
            item = {"status": status, "model": judge["model"], "alignment": records, "metrics": metrics,
                    "failures": failures, "eligible_sample_count": eligible, "completed_sample_count": completed,
                    "output_dir": str(folder), "request_stats": stats}
            log(f'[裁判结果] {name}: {status}，完整评分 {completed}/{eligible}')
            return name, item

        workers = config.get("workers", 1)
        if type(workers) is not int or not 1 <= workers <= 16:
            raise ValueError("裁判 workers 必须为 1–16 的整数")
        if workers == 1:
            items = map(evaluate_judge, judges)
            for name, item in items:
                result["per_judge"][name] = item
                result["complete"] &= item["status"] == "COMPLETED"
        else:
            with ThreadPoolExecutor(max_workers=min(workers, len(judges)), thread_name_prefix="judge") as pool:
                for name, item in pool.map(evaluate_judge, judges):
                    result["per_judge"][name] = item
                    result["complete"] &= item["status"] == "COMPLETED"
        result["request_stats"] = _stats(journal.calls())
        _write(directory / "results.json", result)
        return result
    finally:
        journal.close()
