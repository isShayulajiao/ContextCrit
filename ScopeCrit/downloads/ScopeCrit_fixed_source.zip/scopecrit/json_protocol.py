"""模型 JSON 的无损包装解析及不回显输入值的结构诊断。

仅接受一个完整 JSON 值或一整块 Markdown JSON 围栏；不猜测字段、标签、
ID、主张或配对。语义和业务权限仍由原 schema / engine / evaluator 校验。
"""
from __future__ import annotations

import json
import math
import re

from pydantic import ValidationError


class ProtocolJSONError(ValueError):
    def __init__(self, code):
        self.protocol_code = code
        super().__init__(code)


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ProtocolJSONError("JSON_DUPLICATE_KEY")
        result[key] = value
    return result


def _nonfinite(value):
    raise ProtocolJSONError("JSON_NONFINITE_NUMBER")


def _float(value):
    result = float(value)
    if not math.isfinite(result):
        raise ProtocolJSONError("JSON_NONFINITE_NUMBER")
    return result


def parse_model_json(text):
    if not isinstance(text, str):
        raise ProtocolJSONError("JSON_RESPONSE_NOT_TEXT")
    value = text.strip().lstrip("\ufeff").strip()
    if value.startswith("```"):
        matched = re.fullmatch(r"```(?:json)?[ \t]*\r?\n([\s\S]*?)\r?\n```", value, re.IGNORECASE)
        if not matched:
            raise ProtocolJSONError("JSON_WRAPPER_INVALID")
        value = matched.group(1).strip()
    if not value:
        raise ProtocolJSONError("JSON_RESPONSE_EMPTY")
    try:
        return json.loads(value, object_pairs_hook=_pairs, parse_constant=_nonfinite, parse_float=_float)
    except ProtocolJSONError:
        raise
    except RecursionError:
        raise ProtocolJSONError("JSON_NESTING_TOO_DEEP") from None
    except json.JSONDecodeError:
        raise ProtocolJSONError("JSON_SYNTAX_INVALID") from None
    except ValueError:
        raise ProtocolJSONError("JSON_NUMBER_INVALID") from None


def _path(value):
    if not isinstance(value, (tuple, list)):
        return []
    return [part if type(part) is int or (isinstance(part, str) and
            re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,63}", part)) else "<field>" for part in value]


def _code(value, default):
    return value if isinstance(value, str) and re.fullmatch(r"[A-Z][A-Z0-9_]{1,95}", value) else default


def validation_feedback(exc):
    """只返回字段路径、约束类别和数值限制，不返回响应、Key 或异常原文。"""
    if isinstance(exc, ValidationError):
        issues = []
        for item in exc.errors(include_input=False, include_url=False, include_context=True)[:12]:
            loc = list(item["loc"])
            if item["type"] == "extra_forbidden" and loc:
                loc[-1] = "<unknown_field>"
            issue = {"path": _path(loc), "type": item["type"]}
            constraints = {key: value for key, value in (item.get("ctx") or {}).items()
                           if key in ("max_length", "min_length", "le", "lt", "ge", "gt")
                           and type(value) in (int, float)}
            if constraints:
                issue["constraints"] = constraints
            issues.append(issue)
        return {"code": "SCHEMA_VALIDATION_FAILED", "issues": issues}
    code = getattr(exc, "protocol_code", None)
    if code is None:
        text = str(exc)
        code = text.split(":", 1)[0] if re.match(r"^[A-Z][A-Z0-9_]+(?::|$)", text) else None
    issues = []
    for issue in getattr(exc, "protocol_issues", [])[:12]:
        if not isinstance(issue, dict):
            continue
        kind = issue.get("type", "invalid")
        issues.append({"path": _path(issue.get("path", [])),
                       "type": kind if isinstance(kind, str) and re.fullmatch(r"[A-Za-z0-9_]{1,80}", kind) else "invalid"})
    return {"code": _code(code, "VALIDATION_ERROR"), "issues": issues}
