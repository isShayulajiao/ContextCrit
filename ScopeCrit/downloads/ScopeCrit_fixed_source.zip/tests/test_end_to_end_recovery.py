"""真实 SDK 的离线协议故障注入；按用户命令形状运行到三裁判正式总分。"""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
from threading import Barrier, Lock, get_ident

import httpx
import openai
import yaml

from scopecrit.providers import prompt_text

ROOT = Path(__file__).resolve().parents[1]


def test_cli_recovers_actor_and_three_judges_and_exports_formal_scores(tmp_path, monkeypatch):
    rows = json.loads((ROOT / "examples/merged_demo.json").read_text())
    source = tmp_path / "review.json"
    source.write_text(json.dumps(rows, ensure_ascii=False))
    script = json.loads((ROOT / "examples/mock_script.json").read_text())
    alignments = json.loads((ROOT / "examples/alignment_demo.json").read_text())
    config = tmp_path / "agent.yaml"
    config.write_text(yaml.safe_dump({"fixture": True, "provider": {"kind": "deepseek"},
        "evaluation": {"semantic_alignment": "llm", "enable_paid_judge": True,
                       "judges_config": str(ROOT / "configs/judges.yaml")}}))
    private = tmp_path / "settings.local.yaml"
    fake_keys = {name: f"FAKE_{name}_E2E_PRIVATE_CANARY" for name in ("deepseek", "qwen", "minimax", "gemini")}
    private.write_text(yaml.safe_dump({"inputs": [str(source)], "agent_config": str(config),
        "api_keys": fake_keys, "qwen_base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
        "judges_config": str(ROOT / "configs/judges.yaml")}))
    barrier, lock = Barrier(4), Lock()
    active, actor_positions, actor_attempts, judge_attempts = {}, {}, {}, {}
    actor_calls, judge_calls, repairs = [], [], []

    def transport(request):
        payload = json.loads(request.content)
        data = json.loads(payload["messages"][1]["content"])
        assert payload["max_tokens"] == 32768
        assert "gold" not in data
        if "targets" in data:
            model, sid = payload["model"], data["targets"][0]["sample_id"]
            key = (model, sid)
            with lock:
                attempt = judge_attempts.get(key, 0)
                judge_attempts[key] = attempt + 1
                judge_calls.append(key)
            records = deepcopy([record for record in alignments if record["sample_id"] == sid])
            if sid.endswith(":T1") and attempt == 0:
                # 非法主张 ID 不得被静默删掉或算作正确；必须反馈并重新请求。
                records[0]["matches"][0]["predicted_claim_id"] = "NONEXISTENT_ID"
            elif sid.endswith(":T1"):
                feedback = data["format_repair"]["validation"]
                assert feedback["issues"] and feedback["code"].startswith("JUDGE_")
                repairs.append((model, feedback["code"]))
            response = {"alignments": records}
        else:
            tid = get_ident()
            with lock:
                if "episode_id" in data:
                    active[tid] = data["episode_id"]
                sid = active[tid]
                position = actor_positions.get(sid, 0)
                attempt = actor_attempts.get(sid, 0)
                actor_attempts[sid] = attempt + 1
                actor_calls.append((sid, attempt))
            if attempt == 0:
                barrier.wait(timeout=10)
            entry = script[sid][position]
            assert payload["messages"][0]["content"].startswith(prompt_text(entry["stage"]))
            response = deepcopy(entry["response"])
            if sid.endswith(":T1") and attempt == 0:
                response["arguments"]["gaps"][0]["gap_id"] = "UNCREATED_GAP"
            elif sid.endswith(":T3") and attempt == 0:
                response["reason"] = "reason too long " * 30
            else:
                if sid.endswith(":T1") and position == 0:
                    assert data["recovery_feedback"]["error_code"] == "INVALID_ARGUMENTS"
                    assert data["allowed_ids"]["gap_ids"] == []
                if sid.endswith(":T3") and position == 0:
                    assert data["format_repair"]["validation_feedback"]["issues"]
                with lock:
                    actor_positions[sid] = position + 1
        # 合法的整块 JSON 围栏不改变含义，不应再被当作语义/字段错误。
        content = '```json\n' + json.dumps(response, ensure_ascii=False) + '\n```'
        return httpx.Response(200, json={"id": "e2e-local", "object": "chat.completion", "created": 0,
            "model": payload["model"], "choices": [{"index": 0, "finish_reason": "stop",
            "message": {"role": "assistant", "content": content, "reasoning_content": "HIDDEN_REASONING_CANARY"}}],
            "usage": {"prompt_tokens": 2, "completion_tokens": 3, "total_tokens": 5}})

    actual_openai = openai.OpenAI

    def client(**kwargs):
        return actual_openai(**kwargs, http_client=httpx.Client(transport=httpx.MockTransport(transport)))

    monkeypatch.setattr(openai, "OpenAI", client)
    spec = importlib.util.spec_from_file_location("recovery_launcher", ROOT / "run.py")
    app = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(app)
    old_dir = tmp_path / "runs/parallel_test"
    old_dir.mkdir(parents=True)
    (old_dir / "judge_summary.json").write_text('{"historical":true}')
    command = ["--settings", str(private), "--max-samples", "600", "--workers", "4", "--run-dir", str(old_dir)]
    assert app.main(command) == 0
    assert (old_dir / "judge_summary.json").read_text() == '{"historical":true}'
    outputs = list((tmp_path / "runs").glob("parallel_test_*/judge_summary.json"))
    assert len(outputs) == 1
    output = outputs[0].parent
    report = json.loads(outputs[0].read_text())
    assert report["judging_complete"] is True
    assert report["overall"]["macro_task_score"] == 1.0
    assert all(report["per_task"][task]["composite"]["mean"] == 1.0 for task in ("T1", "T2", "T3", "T4"))
    assert set(report["per_judge"]) == {"qwen3.8-flash", "minimax-m3.1-flash", "gemini-3.1-flash-lite"}
    assert report["overall"]["program_summary"]["status_counts"] == {"COMPLETED": 4}
    assert len(actor_calls) == 37 and len(judge_calls) == 15 and len(repairs) == 3
    assert (output / "scores_overview.csv").is_file() and (output / "scores_overview.json").is_file()
    # 正式评分已完成后的单独评分必须复用响应，不追加 API 请求。
    assert app.main(["--settings", str(private), "--evaluate-only", "--run-dir", str(output)]) == 0
    assert len(actor_calls) == 37 and len(judge_calls) == 15
    for file in output.rglob("*"):
        if file.is_file():
            content = file.read_bytes()
            assert b"HIDDEN_REASONING_CANARY" not in content
            assert all(value.encode() not in content for value in fake_keys.values())
