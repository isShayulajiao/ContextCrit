"""展示分不填补缺失评分，执行状态和裁判覆盖必须分开。"""
from copy import deepcopy
import csv
import json

import pytest

from scopecrit.reporting import COMPOSITES, format_console, write_results_overview
from scopecrit.results_overview import build_results_overview


NAMES = ["裁判甲", "裁判乙", "裁判丙"]
TASKS = ("T1", "T2", "T3", "T4")


@pytest.fixture
def partial_report():
    baseline = [{"sample_id": task, "task": task, "status": "COMPLETED",
                 "semantic_counts": {"scored": False, "predicted": 1, "expected": 1},
                 "needs_alignment": True} for task in TASKS]
    baseline.append({"sample_id": "空失败", "task": "T1", "status": "PARTIAL",
                     "semantic_counts": {"scored": True, "predicted": 0, "expected": 1},
                     "needs_alignment": False})
    metric = {"source": "judges", "mean": None, "available_mean": 0.4,
              "valid_judges": 1, "expected_judges": 3, "complete": False,
              "per_judge": {NAMES[0]: {"value": 0.2, "complete": False},
                            NAMES[1]: {"value": 0.4, "complete": True},
                            NAMES[2]: {"value": None, "complete": False}}}
    composite = deepcopy(metric)
    composite["per_judge"][NAMES[0]]["value"] = None
    program = {"source": "program", "mean": 0.0, "available_mean": 0.0,
               "valid_judges": 0, "expected_judges": 0, "complete": True, "per_judge": {}}
    per_task = {task: {"metrics": {"aspect_micro_f1": deepcopy(metric), "evidence_f1": deepcopy(program)},
                       "composite": {**deepcopy(composite), "weights": deepcopy(COMPOSITES[task])}}
                for task in TASKS}
    judges = {}
    for name in NAMES:
        samples = deepcopy(baseline)
        for sample in samples:
            if name == NAMES[1] or (name == NAMES[0] and sample["task"] == "T1"):
                sample["semantic_counts"]["scored"] = True
                sample["needs_alignment"] = False
        judges[name] = {"status": "PARTIAL", "metrics": {"per_sample": samples}}
    return {
        "dataset_name": "不完整中文数据集", "expected_judges": NAMES,
        "judging_complete": False,
        "methodology": {"composite_weights": deepcopy(COMPOSITES)},
        "overall": {"macro_task_score": None, "available_task_mean": None,
                    "valid_tasks": 0, "metrics": {"aspect_micro_f1": deepcopy(metric)},
                    "program_summary": {"count": 5, "status_counts": {"COMPLETED": 4, "PARTIAL": 1}}},
        "per_task": per_task, "per_judge": judges,
        "per_sample": [{"sample_id": s["sample_id"], "task": s["task"], "status": s["status"], "program": s}
                       for s in baseline],
    }


def test_overview_retains_incomplete_judge_raw_values_without_promoting_them(partial_report):
    before = deepcopy(partial_report)
    overview = build_results_overview(partial_report)
    rows = overview["rows"]
    formal = [r for r in rows if r["row_type"] == "正式值"
              and r["metric"] in ("macro_task_score", "composite", "aspect_micro_f1")]
    assert all(r["raw_0_1"] is None and r["display_0_100"] is None and not r["complete"] for r in formal)
    raw = next(r for r in rows if r["task"] == "T1" and r["metric"] == "aspect_micro_f1" and r["judge"] == NAMES[0])
    assert raw["raw_0_1"] == 0.2
    assert raw["display_0_100"] == 20
    assert raw["diagnostic"] and not raw["complete"]
    available = next(r for r in rows if r["task"] == "T1" and r["metric"] == "aspect_micro_f1"
                     and r["row_type"] == "可用值（诊断）")
    assert available["raw_0_1"] == 0.4 and available["diagnostic"]
    assert partial_report == before


def test_per_judge_overall_requires_all_four_original_composites(partial_report):
    rows = build_results_overview(partial_report)["rows"]
    overall = {r["judge"]: r for r in rows if r["metric"] == "macro_task_score" and r["judge"]}
    assert overall[NAMES[1]]["raw_0_1"] == 0.4
    assert overall[NAMES[1]]["valid_tasks"] == 4
    assert overall[NAMES[0]]["raw_0_1"] is None
    partial_report["per_task"]["T4"]["composite"]["per_judge"][NAMES[1]] = {"value": None, "complete": False}
    rows = build_results_overview(partial_report)["rows"]
    incomplete = next(r for r in rows if r["metric"] == "macro_task_score" and r["judge"] == NAMES[1])
    assert incomplete["raw_0_1"] is None
    assert incomplete["valid_tasks"] == 3
    assert not incomplete["complete"]


def test_coverage_distinguishes_real_nonempty_judging_from_failure_auto_zeros(partial_report):
    coverage = build_results_overview(partial_report)["coverage"]
    assert coverage["sample_status_counts"] == {"COMPLETED": 4, "PARTIAL": 1}
    assert coverage["judging_complete"] is False
    assert coverage["formal_scores_complete"] is False
    full = coverage["per_judge"][NAMES[1]]["overall"]
    assert full["expected_samples"] == full["semantic_scored_samples"] == 5
    assert full["nonempty_graded_samples"] == full["nonempty_prediction_samples"] == 4
    assert full["failed_empty_auto_zero_samples"] == 1
    empty_only = coverage["per_judge"][NAMES[2]]["overall"]
    assert empty_only["semantic_scored_samples"] == empty_only["failed_empty_auto_zero_samples"] == 1
    assert empty_only["nonempty_graded_samples"] == 0
    assert empty_only["nonempty_judging_coverage_raw_0_1"] == 0
    console = format_console(partial_report)
    assert "COMPLETED=4；PARTIAL=1" in console
    assert "judging_complete=否" in console
    assert "失败空预测自动零分" in console
    assert "20.0000（不完整）" in console


def test_unknown_process_status_and_unproved_empty_zero_are_not_inferred(partial_report):
    del partial_report["judging_complete"]
    baseline = partial_report["per_sample"][-1]["program"]
    baseline["semantic_counts"]["scored"] = False
    baseline["needs_alignment"] = True
    coverage = build_results_overview(partial_report)["coverage"]
    assert coverage["judging_complete"] is None
    assert coverage["per_judge"][NAMES[1]]["overall"]["failed_empty_auto_zero_samples"] == 0
    assert coverage["per_judge"][NAMES[1]]["overall"]["other_empty_scored_samples"] == 1


def test_writer_has_chinese_labels_and_keeps_null_separate_from_zero(partial_report, tmp_path):
    write_results_overview(partial_report, tmp_path)
    saved = json.loads((tmp_path / "scores_overview.json").read_text(encoding="utf-8"))
    assert saved["rows"][0]["raw_0_1"] is None
    assert saved["composite_weights"] == COMPOSITES
    with (tmp_path / "scores_overview.csv").open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    assert rows[0]["指标说明"] == "四任务综合分等权宏平均"
    assert rows[0]["原始分_0至1"] == rows[0]["展示分_0至100"] == ""
    zero = next(r for r in rows if r["任务"] == "T1" and r["指标代码"] == "evidence_f1")
    assert float(zero["原始分_0至1"]) == float(zero["展示分_0至100"]) == 0
    assert zero["该项评分完整"] == "True"
