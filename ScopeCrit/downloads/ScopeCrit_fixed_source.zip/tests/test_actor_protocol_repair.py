"""Fresh local actor responses exercise recovery without API access or gold hints."""
from copy import deepcopy
import json

import pytest
from pydantic import ValidationError

from scopecrit.config import Config
from scopecrit.engine import Engine, ToolError
from scopecrit.schemas import parse_action
from scopecrit.storage import Store
from test_engine import ScriptProvider, action, check, claim, engine, relation, sample


def gap(gap_id=None):
    return {"gap_id": gap_id, "kind": "SCOPE", "question": "当前证据能否支持整体判断？",
            "related_claim_ids": [], "status": "OPEN", "resolution_claim_ids": []}


def fenced(value):
    return "```json\n" + json.dumps(value, ensure_ascii=False) + "\n```"


def test_runtime_invented_gap_id_recovers_via_explicit_null_and_existing_defer(tmp_path):
    runner, provider, store = engine(tmp_path, [
        ("ACTION", action("PLAN_GAPS", gaps=[gap("G001")])),
        ("ACTION", action("PLAN_GAPS", gaps=[gap(None)])),
        ("ACTION", action("DEFER", gap_id="G999", reason="目前无更多依据")),
        ("ACTION", action("DEFER", gap_id="G001", reason="当前依据不足，保留缺口")),
        ("ACTION", action("FINALIZE", claim_ids=[], answer="当前依据不足，暂不形成已支持的评价。")),
    ])
    output = runner.run()
    assert output["status"] == "COMPLETED"
    assert output["prediction"]["claims"] == []
    assert list(runner.role["gaps"]) == ["G001"]
    assert runner.role["gaps"]["G001"]["status"] == "DEFERRED"
    after_rejection = provider.requests[1][1]
    assert after_rejection["allowed_ids"]["gap_ids"] == []
    assert after_rejection["gaps"] == []
    assert "gap_id:null" in after_rejection["recovery_feedback"]["message"]
    assert provider.requests[3][1]["allowed_ids"]["gap_ids"] == ["G001"]
    rejected = [event for event in store.list_events()
                if event.get("result", {}).get("error_code") == "INVALID_ARGUMENTS"]
    assert len(rejected) == 2
    assert output["usage"]["model_calls"] == 5


def test_gap_creation_does_not_accept_empty_or_predicted_batch_ids(tmp_path):
    with pytest.raises(ValidationError):
        parse_action(json.dumps(action("PLAN_GAPS", gaps=[gap("")])))
    cfg = Config().model_dump()
    cfg["limits"]["max_actions_per_episode"] = 1
    runner, _, _ = engine(tmp_path, [
        ("ACTION", action("PLAN_GAPS", gaps=[gap(None), gap("G001")]))
    ], config=cfg)
    output = runner.run()
    assert runner.role["gaps"] == {}
    assert output["prediction"]["claims"] == []
    assert runner.role["last_tool_result"]["error_code"] == "INVALID_ARGUMENTS"


def test_unknown_gap_and_candidate_ids_still_rejected(tmp_path):
    runner, _, _ = engine(tmp_path, [])
    runner.initialize()
    for invalid_action in (
        action("PLAN_GAPS", gaps=[gap("G999")]),
        action("DEFER", gap_id="G999", reason="延期"),
        action("COMMIT", candidate_id="P999"),
    ):
        with pytest.raises(ToolError):
            runner.execute(invalid_action)
    assert runner.role["gaps"] == runner.role["candidates"] == runner.role["committed"] == {}


def test_reason_length_feedback_is_precise_safe_and_budgeted(tmp_path):
    private_response = "PRIVATE_MODEL_RESPONSE_CANARY" + "详" * 241
    malformed = action("READ", evidence_ids=["E001"])
    malformed["reason"] = private_response
    cfg = Config().model_dump()
    cfg["limits"]["max_actions_per_episode"] = 1
    runner, provider, _ = engine(tmp_path, [
        ("ACTION", malformed),
        ("ACTION", action("READ", evidence_ids=["E001"])),
    ], config=cfg)
    output = runner.run()
    repaired_request = provider.requests[1][1]
    feedback = repaired_request["format_repair"]["validation_feedback"]
    assert feedback["code"] == "SCHEMA_VALIDATION_FAILED"
    assert any(issue["path"][-1] == "reason" and issue["type"] == "string_too_long"
               and issue["constraints"]["max_length"] == 240 for issue in feedback["issues"])
    assert "PRIVATE_MODEL_RESPONSE_CANARY" not in json.dumps(repaired_request)
    assert output["usage"]["model_calls"] == 2
    assert output["termination_reason"] == "ACTION_BUDGET_EXHAUSTED"


def test_exhausted_format_repairs_remain_partial_without_semantic_changes(tmp_path):
    cfg = Config().model_dump()
    cfg["limits"]["max_actions_per_episode"] = 1
    runner, provider, _ = engine(tmp_path, [
        ("ACTION", '{"action":"READ","arguments":{"evidence_ids":["E001"]},"reason":"unfinished'),
        ("ACTION", "Still not JSON: PRIVATE_BAD_RESPONSE_CANARY"),
    ], config=cfg)
    output = runner.run()
    assert len(provider.requests) == output["usage"]["model_calls"] == 2
    assert output["status"] == "PARTIAL"
    assert output["prediction"]["claims"] == []
    assert output["prediction"]["answer"] == ""
    assert runner.role["last_tool_result"]["error_code"] == "INVALID_ACTION"
    assert "PRIVATE_BAD_RESPONSE_CANARY" not in json.dumps(runner.build_view())


def test_whole_response_json_fences_work_in_all_actor_stages_without_repair(tmp_path):
    runner, provider, _ = engine(tmp_path, [
        ("ACTION", fenced(action("PROPOSE", claims=[claim()]))),
        ("ACTION", action("COMMIT", candidate_id="P001")),
        ("SUPPORT_CHECK", fenced(check())),
        ("ACTION", action("COMPARE", claim_ids=["P001"], evidence_ids=["E001"], question="这项判断的范围？")),
        ("SCOPE_COMPARE", fenced(relation())),
        ("ACTION", action("FINALIZE", claim_ids=["P001"], relation_ids=["R001"], answer="整体结构严谨[E001]")),
    ])
    output = runner.run()
    assert output["status"] == "COMPLETED"
    assert output["usage"]["model_calls"] == 6
    assert all("format_repair" not in request for _, request, _ in provider.requests)
    assert output["prediction"]["claims"][0]["text"] == claim()["text"]


def test_valid_negative_commits_do_not_trigger_protocol_streak_or_recheck(tmp_path):
    claims = [claim(text=text) for text in ("整体结构严谨", "整体结构可能严谨", "整体结构有待判断")]
    runner, provider, store = engine(tmp_path, [
        ("ACTION", action("PROPOSE", claims=claims)),
        ("ACTION", action("COMMIT", candidate_id="P001")),
        ("SUPPORT_CHECK", check("P001", support="PARTIAL")),
        ("ACTION", action("COMMIT", candidate_id="P002")),
        ("SUPPORT_CHECK", check("P002", support="UNSUPPORTED")),
        ("ACTION", action("COMMIT", candidate_id="P003")),
        ("SUPPORT_CHECK", check("P003", support="UNCERTAIN")),
        ("ACTION", action("COMMIT", candidate_id="P001")),
        ("ACTION", action("FINALIZE", claim_ids=[], answer="当前三个候选均未获充分支持，保留判断。")),
    ])
    output = runner.run()
    assert output["status"] == "COMPLETED"
    assert runner.state["invalid_streak"] == 0
    assert output["prediction"]["claims"] == []
    assert [candidate["status"] for candidate in runner.role["candidates"].values()] == ["DEFERRED", "REJECTED", "DEFERRED"]
    assert sum(stage == "SUPPORT_CHECK" for stage, _, _ in provider.requests) == 3
    commit_results = [event["result"] for event in store.list_events()
                      if event.get("action", {}).get("action") == "COMMIT"]
    assert len(commit_results) == 4
    assert all(result["ok"] is False and result["error_code"] == "SUPPORT_NOT_CONFIRMED" for result in commit_results)
    assert commit_results[-1]["replayed"] is True


def test_t4_repair_and_allowed_ids_remain_role_local(tmp_path):
    malformed = action("READ", evidence_ids=["E001"])
    malformed["reason"] = "ARCHIVIST_RESPONSE_CANARY" + "长" * 241
    runner, provider, _ = engine(tmp_path, [
        ("ACTION", malformed),
        ("ACTION", action("YIELD")),
        ("ACTION", action("FINALIZE", claim_ids=[], answer="当前尚无已支持的联合判断。")),
    ], task="T4")
    output = runner.run()
    assert output["status"] == "COMPLETED"
    for _, request, _ in provider.requests[:2]:
        assert request["allowed_ids"]["visible_evidence_ids"] == ["E001"]
        assert "FINALIZE" not in request["allowed_actions"]
        assert "PRIVATE_FUTURE_CANARY" not in json.dumps(request)
    interpreter_view = provider.requests[2][1]
    assert interpreter_view["allowed_ids"]["visible_evidence_ids"] == ["E002"]
    assert "FINALIZE" in interpreter_view["allowed_actions"]
    assert "format_repair" not in interpreter_view
    assert "recovery_feedback" not in interpreter_view
    assert "ARCHIVIST_RESPONSE_CANARY" not in json.dumps(interpreter_view)
    assert all("GOLD_" not in json.dumps(request) and "document_text" not in request
               for _, request, _ in provider.requests)


def test_t3_repair_ids_and_logs_preserve_turn_boundary(tmp_path):
    malformed = action("FINALIZE", claim_ids=["P001"], answer="结构严谨[E001]")
    malformed["reason"] = "TURN_ONE_RESPONSE_CANARY" + "长" * 241
    provider = ScriptProvider([
        ("ACTION", action("PROPOSE", claims=[claim()])),
        ("ACTION", action("COMMIT", candidate_id="P001")),
        ("SUPPORT_CHECK", check()),
        ("ACTION", malformed),
        ("ACTION", action("FINALIZE", claim_ids=["P001"], answer="结构严谨[E001]")),
        ("ACTION", action("FINALIZE", claim_ids=["P001"], answer="原有整体判断仍保留，新证据暂未形成新主张[E001]")),
    ])
    lines = []
    runner = Engine(sample("T3"), Config().model_dump(), provider, Store(tmp_path), log=lines.append)
    output = runner.run()
    assert output["status"] == "COMPLETED"
    for _, request, _ in provider.requests[:5]:
        assert "PRIVATE_FUTURE_CANARY" not in json.dumps(request)
        assert "E002" not in json.dumps(request)
    turn_two = provider.requests[5][1]
    assert turn_two["allowed_ids"]["visible_evidence_ids"] == ["E001", "E002"]
    assert "format_repair" not in turn_two
    assert "TURN_ONE_RESPONSE_CANARY" not in json.dumps(turn_two)
    assert all("GOLD_" not in json.dumps(request) and "document_text" not in request
               for _, request, _ in provider.requests)
    assert all(line.startswith("[sample_id=Synthetic:T3 role=solo turn=") and " step=" in line for line in lines)
    final_lines = [line for line in lines if "[动作] FINALIZE" in line]
    assert "turn=1 step=3" in final_lines[0]
    assert "turn=2 step=4" in final_lines[1]
    assert any("[模型]" in line for line in lines)
    assert any("[拒绝]" in line for line in lines)


@pytest.mark.parametrize("task,role", [("T1", "solo"), ("T2", "solo"), ("T3", "solo"), ("T4", "archivist")])
def test_action_affordances_match_task_and_role_without_gold(tmp_path, task, role):
    runner, _, _ = engine(tmp_path, [], task=task)
    runner.initialize()
    view = deepcopy(runner.build_view())
    assert view["role"] == role
    assert ("SEND_EVIDENCE" in view["allowed_actions"]) == (task == "T4")
    assert ("FINALIZE" in view["allowed_actions"]) == (task != "T4")
    assert "GOLD_" not in json.dumps(view)
