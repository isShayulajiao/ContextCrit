import pytest
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from scopecrit.json_protocol import parse_model_json, validation_feedback


@pytest.mark.parametrize("text", ['{"a":1}', '\ufeff {"a":1}', '```json\n{"a":1}\n```', '```\n{"a":1}\n```'])
def test_json_wrapper_is_lossless(text):
    assert parse_model_json(text) == {"a": 1}


@pytest.mark.parametrize("text", ['{"a":1,"a":2}', '{"a":NaN}', '{"a":Infinity}', '{"a":1} trailing',
    'Here is JSON: {"a":1}', '```json\n{"a":1}\n```\n```json\n{}\n```', '', '{"a":1,}'])
def test_ambiguous_and_changed_semantics_not_repaired_locally(text):
    with pytest.raises(ValueError):
        parse_model_json(text)


def test_feedback_never_echoes_values_or_unknown_field_names():
    secret = "sk-PRIVATE_CANARY_NOT_FOR_LOGS"

    class Schema(BaseModel):
        model_config = ConfigDict(extra="forbid", strict=True)
        reason: str = Field(max_length=4)
        count: int

    with pytest.raises(ValidationError) as caught:
        Schema.model_validate({"reason": secret, "count": secret, secret: secret})
    result = validation_feedback(caught.value)
    assert secret not in str(result)
    assert result["code"] == "SCHEMA_VALIDATION_FAILED"
    assert any(issue.get("constraints") == {"max_length": 4} for issue in result["issues"])


def test_generic_error_does_not_echo_raw_exception():
    assert validation_feedback(ValueError("sk-PRIVATE_CANARY")) == {"code": "VALIDATION_ERROR", "issues": []}
    assert validation_feedback(ValueError("JUDGE_TARGET_MISMATCH"))["code"] == "JUDGE_TARGET_MISMATCH"


def test_json_overflow_is_not_accepted_as_finite_json_number():
    with pytest.raises(ValueError, match="JSON_NONFINITE_NUMBER"):
        parse_model_json('{"value":1e999}')


def test_deeply_nested_model_output_is_a_recoverable_protocol_error():
    with pytest.raises(ValueError, match="JSON_NESTING_TOO_DEEP"):
        parse_model_json('[' * 10000 + '0' + ']' * 10000)
